Nethrion XP Exchange Machine

Schematic size: 3 wide x 3 deep x 4 high.
Front is z=0. Origin is the front-left-bottom block.
Use WorldEdit to paste the .schem.
Fallback build.mcfunction uses relative ~ coordinates.
